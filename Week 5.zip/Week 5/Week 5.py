#Erica Skoog
#Week 5

import statesdict
import requests
import psutil
#import dictionary, requests, and psutil
hugo = "https://gohugo.io"
#ask user for a number input
try:
    num = int(input("Enter a number: "))
#verify that the input is a number
except ValueError:
    print("Invalid input")
    exit()

#Now run an if statements to determine if the number is divisible by 5
if num %  5 == 0:
    print(f"The number {num} is divisible by 5.")
else:
    print(f"The number {num} is not divisible by 5.")

#ask user to enter a state
state = input("Please enter a state: ")
capital = statesdict.states.get(state)
#pull the state and capital information from the library
if capital:
    print(f"The capital of {state} is {capital}")
#print out the state and capital or tell the user there is no capital in the dictionary
else:
    print(f"Sorry, the capital of {state} is can't be found.")

#ask the people entering the pool so we can determine how much the need to pay
age = int(input("How old are you?: "))

if age < 2:
    print("0")
elif age < 12:
    print("3")
elif age < 61:
    print("6")
else:
    print("4")


try:
    response = requests.get(hugo)
    html = response.text

    hugo_count = html.count("Hugo")
    print(f'the substring "Hugo" appears {hugo_count} times in the HTML source of {hugo}.')

except requests.RequestException as e:
    print("Couldn't fetch Hugo page.")

processes = psutil.pids()
num_processes = len(processes)

print(f"Number of running processes: {num_processes}")